from .__jsonReader import JsonReader
from .__jsonReader import __doc__ as JsonReader__doc__

__doc__ = JsonReader__doc__
__author__ = "heureka-code"
__maintainer__ = "heureka-code"
__version__ = "0.0.4"
